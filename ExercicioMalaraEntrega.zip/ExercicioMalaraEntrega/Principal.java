
public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Amigo a1 = new Amigo();
		a1.setDataAniver("08/02/1999");
		a1.setIdade(20);
		a1.setNome("Matheus");
		a1.mostraDados();
		Conhecido c1 = new Conhecido();
		c1.setEmail("teste@gmail.com");
		c1.setIdade(20);
		c1.setNome("Donizetti");
		Agenda ag = new Agenda(1,5);
		ag.imprimeTudo();
		
		}

}
