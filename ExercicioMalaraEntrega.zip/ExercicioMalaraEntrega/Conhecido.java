
public class Conhecido extends Pessoa {

	protected String email;

	@Override
	public void mostraDados() {
		// TODO Auto-generated method stub
		System.out.println("[Conhecido]"  + "\n<nome>" + nome + "\n<idade>" + idade + "\n<email>" + email);
	}

	public Conhecido() {
		super();
		email = "Sem E-mail";
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
