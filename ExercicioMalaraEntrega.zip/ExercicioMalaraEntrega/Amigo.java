
public class Amigo extends Pessoa {

	protected String dataAniver;

	public Amigo() {
		super();
		dataAniver = "Sem Anives�rio";
	}

	public String getDataAniver() {
		return dataAniver;
	}

	public void setDataAniver(String dataAniver) {
		this.dataAniver = dataAniver;
	}

	public Amigo(String nome, int idade, String dataAniver) {
		super(nome, idade);
		this.dataAniver = dataAniver;
	}

	@Override
	public void mostraDados() {
		System.out.println("[Amigo]" + "\n<nome> " + nome + "\n<idade> " + idade + "\n<data de Anivers�rio> " + dataAniver);

	}

}
