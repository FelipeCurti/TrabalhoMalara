import java.util.Scanner;

public class Agenda {
	private Pessoa[] vet;
	protected int qntPessoas = 0;
	protected int MaxPessoas = 10;
	
	Scanner s = new Scanner(System.in);
	int i;
	
	public void addContato() {
        if (MaxPessoas == qntPessoas) {
            Conhecido c = new Conhecido();
            c.setEmail(s.next());
            vet[qntPessoas].setNome(s.next());
            vet[qntPessoas].setIdade(s.nextInt());
            vet[qntPessoas] = c;
            qntPessoas++;
        } else {
            System.out.println("Erro");
        }
    }

    public void addAmigo() {
        if (MaxPessoas == qntPessoas) {
            Amigo a1 =  new Amigo();
            a1.setDataAniver(s.next());
            vet[qntPessoas].setNome(s.next());
            vet[qntPessoas].setIdade(s.nextInt());
            vet[qntPessoas] = a1;
            qntPessoas++;
        } else {
            System.out.println("Erro");
        }
    }
    
    public void imprimeTudo() {
    	vet[qntPessoas].mostraDados();
    	}
    
    public void imprimeAniversarios() {
    	
    }
    

	public Agenda(int qntPessoas, int maxPessoas) {
		super();
		vet = new Pessoa[10];
		this.qntPessoas = 0;
		MaxPessoas = maxPessoas;
	}

	public Agenda() {
		// TODO Auto-generated constructor stub
	}

	public Pessoa[] getVet() {
		return vet;
	}

	public void setVet(Pessoa[] vet) {
		this.vet = vet;
	}

	public int getQntPessoas() {
		return qntPessoas;
	}

	public void setQntPessoas(int qntPessoas) {
		this.qntPessoas = qntPessoas;
	}

	public int getMaxPessoas() {
		return MaxPessoas;
	}

	public void setMaxPessoas(int maxPessoas) {
		MaxPessoas = maxPessoas;
	}

}
